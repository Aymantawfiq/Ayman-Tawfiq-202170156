Ayman Tawfiq Abdulbaki Mohammed 202170156
Eyad Khaled Hussen Al-Sayaghi 202170048

The project (Lung Cancer detection):
build program train on three classifications:
1.Normal Class 
2.Lung Adenocarcinomas 
3.Lung Squamous Cell Carcinomas
15000 images for this model 5000 for every one 

operating:
give it path of images and it starts train on images 
in the end give you model trained
you can use to check another pictures

the report in pdf
